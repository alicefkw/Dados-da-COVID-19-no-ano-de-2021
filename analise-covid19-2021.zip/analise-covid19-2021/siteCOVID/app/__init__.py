from flask import Flask, render_template, Response
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import pandas as pd
import io
from pylab import rcParams

def pushDataset1sem():
    return pd.read_csv(
        'app//Datasets//HIST_PAINEL_COVIDBR_2021_Parte1_31out2021.csv',
        sep=';')

def pushDataset2sem():
    return pd.read_csv(
        'app//Datasets//HIST_PAINEL_COVIDBR_2021_Parte2_31out2021.csv',
        sep=';')

app = Flask(__name__)

# PÁGINA PRINCIPAL
@app.route("/")
def home():
    return render_template('index.html/')

# SOBRE
@app.route("/sobre/")
def sobre():
    return render_template('sobre.html/')
    
# PÁGINA DE REGISTRO
@app.route("/registro/")
def registro():
    return render_template('registro.html/')

# PÁGINA DE LOGIN
@app.route("/login/")
def login():
    return render_template('login.html/')


# ===============================================
# ==============TABELAS DE TAUBATÉ===============
# ===============================================
@app.route('/taubate/')
def taubate():
    return render_template('/Taubate/dados.html/')

@app.route('/taubate2021_pt1/')
def taubate2021_pt1():
    taubate_df = pd.DataFrame(pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'])
    return render_template('/Taubate/1ºsemestre.html', tables=[taubate_df.to_html(classes='taubate_df', table_id="table")])

@app.route('/taubate2021_pt2/')
def taubate2021_pt2():
    taubate_df = pd.DataFrame(pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'])
    return render_template('/Taubate/2ºsemestre.html', tables=[taubate_df.to_html(classes='taubate_df', table_id="table")])


# ===============================================
# ==============GRÁFICOS DE TAUBATÉ==============
# ===============================================
@app.route("/taubate_casosNovos1sem/")
def taubate_casosNovos1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos registrados por data - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovos2sem/")
def taubate_casosNovos2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos registrados por data - 2º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/taubate_casosAcumulados1sem/")
def taubate_casosAcumulados1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].casosAcumulado
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos acumulados (Total) - 1º Sem. 2021', fontsize=15)  # titulo
    axis.set_xlabel('data (semestre inteiro)')  # texto do eixo x
    axis.set_ylabel('casos acumulados')  # texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumulados2sem/")
def taubate_casosAcumulados2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].casosAcumulado
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos acumulados (Total) - 2º Sem. 2021', fontsize=15)  # titulo
    axis.set_xlabel('data (semestre inteiro)')  # texto do eixo x
    axis.set_ylabel('casos acumulados')  # texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/taubate_obitosNovos1sem/")
def taubate_obitosNovos1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].obitosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos registrados por data - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovos2sem/")
def taubate_obitosNovos2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].obitosNovos
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos registrados por data - 2º Sem. 2021', fontsize=15)
    axis.set_xlabel('data (semestre inteiro)')
    axis.set_ylabel('óbitos novos')

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/taubate_obitosAcumulados1sem/")
def taubate_obitosAcumulados1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Taubaté'].obitosAcumulado
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos acumulados (Total) - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumulados2sem/")
def taubate_obitosAcumulados2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Taubaté'].obitosAcumulado
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos acumulados (Total) - 2º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


# ===============================================
# ==========GRÁFICO MENSAL DE TAUBATÉ============
# ===============================================
@app.route('/taubate_casosNovosMes/')
def taubate_casosNovosMes():
    return render_template('/Taubate/casosNovosMes.html/')

@app.route('/taubate_casosAcumuladosMes/')
def taubate_casosAcumuladosMes():
    return render_template('/Taubate/casosAcumuladosMes.html/')

@app.route('/taubate_obitosNovosMes/')
def taubate_obitosNovosMes():
    return render_template('/Taubate/obitosNovosMes.html/')

@app.route('/taubate_obitosAcumuladosMes/')
def taubate_obitosAcumuladosMes():
    return render_template('/Taubate/obitosAcumuladosMes.html/')


@app.route("/taubate_casosNovosMes1/")
def taubate_casosNovosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data <= '2021-01-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes2/")
def taubate_casosNovosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].casosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes3/")
def taubate_casosNovosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes4/")
def taubate_casosNovosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes5/")
def taubate_casosNovosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes6/")
def taubate_casosNovosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes7/")
def taubate_casosNovosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes8/")
def taubate_casosNovosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes9/")
def taubate_casosNovosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                 (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                 (pushDataset2sem().data <= '2021-09-30')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosNovosMes10/")
def taubate_casosNovosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].casosNovos
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/taubate_casosAcumuladosMes1/")
def taubate_casosAcumuladosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') &
                          (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') &
                          (pushDataset1sem().data <= '2021-01-31')].casosAcumulado
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes2")
def taubate_casosAcumuladosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].casosAcumulado
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes3/")
def taubate_casosAcumuladosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].casosAcumulado
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes4/")
def taubate_casosAcumuladosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                 (pushDataset1sem().data <= '2021-04-30')].casosAcumulado
    axis.plot(x,y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes5/")
def taubate_casosAcumuladosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                 (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes6/")
def taubate_casosAcumuladosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes7/")
def taubate_casosAcumuladosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes8/")
def taubate_casosAcumuladosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes9/")
def taubate_casosAcumuladosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_casosAcumuladosMes10/")
def taubate_casosAcumuladosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/taubate_obitosNovosMes1/")
def taubate_obitosNovosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data <= '2021-01-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes2/")
def taubate_obitosNovosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes3/")
def taubate_obitosNovosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes4/")
def taubate_obitosNovosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes5/")
def taubate_obitosNovosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes6/")
def taubate_obitosNovosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes7/")
def taubate_obitosNovosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes8/")
def taubate_obitosNovosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes9/")
def taubate_obitosNovosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosNovosMes10/")
def taubate_obitosNovosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/taubate_obitosAcumuladosMes1/")
def taubate_obitosAcumuladosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data <= '2021-01-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes2/")
def taubate_obitosAcumuladosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes3/")
def taubate_obitosAcumuladosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-03-01') &
                 (pushDataset1sem().data <= '2021-03-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes4/")
def taubate_obitosAcumuladosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes5/")
def taubate_obitosAcumuladosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes6/")
def taubate_obitosAcumuladosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Taubaté') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes7/")
def taubate_obitosAcumuladosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes8/")
def taubate_obitosAcumuladosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes9/")
def taubate_obitosAcumuladosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/taubate_obitosAcumuladosMes10/")
def taubate_obitosAcumuladosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Taubaté') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


# ===============================================
# ==============TABELAS DE TREMEMBÉ==============
# ===============================================
@app.route('/tremembe/')
def tremembe():
    return render_template('/Tremembe/dados.html')

@app.route('/tremembe2021_pt1/')
def tremembe2021_pt1():
    tremembe_df = pd.DataFrame(pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'])
    return render_template('/Tremembe/1ºsemestre.html', tables=[tremembe_df.to_html(classes='tremembe_df', table_id="table")])

@app.route('/tremembe2021_pt2/')
def tremembe2021_pt2():
    tremembe_df = pd.DataFrame(pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'])
    return render_template('/Tremembe/2ºsemestre.html', tables=[tremembe_df.to_html(classes='tremembe_df', table_id="table")])


# ================================================
# ==============GRÁFICOS DE TREMEMBÉ==============
# ================================================
@app.route("/tremembe_casosNovos1sem")
def tremembe_casosNovos1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].casosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos registrados por data - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovos2sem")
def tremembe_casosNovos2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].casosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos registrados por data - 2º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/tremembe_casosAcumulados1sem")
def tremembe_casosAcumulados1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].casosAcumulado
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos acumulados (Total) - 1º Sem. 2021', fontsize=15)  # titulo
    axis.set_xlabel('data (semestre inteiro)')  # texto do eixo x
    axis.set_ylabel('casos acumulados')  # texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumulados2sem")
def tremembe_casosAcumulados2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].casosAcumulado
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos acumulados (Total) - 2º Sem. 2021', fontsize=15)  # titulo
    axis.set_xlabel('data (semestre inteiro)')  # texto do eixo x
    axis.set_ylabel('casos acumulados')  # texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/tremembe_obitosNovos1sem")
def tremembe_obitosNovos1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].obitosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e obitosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos novos (por data) - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovos2sem")
def tremembe_obitosNovos2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].obitosNovos
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos novos (por data) - 2º Sem. 2021', fontsize=15)
    axis.set_xlabel('data (semestre inteiro)')
    axis.set_ylabel('óbitos novos')

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumulados1sem")
def tremembe_obitosAcumulados1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Tremembé'].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos acumulados (Total) - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumulados2sem")
def tremembe_obitosAcumulados2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Tremembé'].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos acumulados (Total) - 2º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


# ===============================================
# ==========GRÁFICO MENSAL DE TREMEMBÉ===========
# ===============================================
@app.route('/tremembe_casosNovosMes/')
def tremembe_casosNovosMes():
    return render_template('/Tremembe/casosNovosMes.html/')

@app.route('/tremembe_casosAcumuladosMes/')
def tremembe_casosAcumuladosMes():
    return render_template('/Tremembe/casosAcumuladosMes.html/')

@app.route('/tremembe_obitosNovosMes/')
def tremembe_obitosNovosMes():
    return render_template('/Tremembe/obitosNovosMes.html/')

@app.route('/tremembe_obitosAcumuladosMes/')
def tremembe_obitosAcumuladosMes():
    return render_template('/Tremembe/obitosAcumuladosMes.html/')


@app.route("/tremembe_casosNovosMes1/")
def tremembe_casosNovosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data <= '2021-01-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes2/")
def tremembe_casosNovosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes3/")
def tremembe_casosNovosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                 (pushDataset1sem().data <= '2021-03-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes4/")
def tremembe_casosNovosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes5/")
def tremembe_casosNovosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes6/")
def tremembe_casosNovosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes7/")
def tremembe_casosNovosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes8/")
def tremembe_casosNovosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes9/")
def tremembe_casosNovosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                 (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                 (pushDataset2sem().data <= '2021-09-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosNovosMes10/")
def tremembe_casosNovosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/tremembe_casosAcumuladosMes1/")
def tremembe_casosAcumuladosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') &
                          (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') &
                          (pushDataset1sem().data <= '2021-01-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes2")
def tremembe_casosAcumuladosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes3/")
def tremembe_casosAcumuladosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes4/")
def tremembe_casosAcumuladosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                 (pushDataset1sem().data <= '2021-04-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes5/")
def tremembe_casosAcumuladosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                 (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes6/")
def tremembe_casosAcumuladosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes7/")
def tremembe_casosAcumuladosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes8/")
def tremembe_casosAcumuladosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes9/")
def tremembe_casosAcumuladosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_casosAcumuladosMes10/")
def tremembe_casosAcumuladosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/tremembe_obitosNovosMes1/")
def tremembe_obitosNovosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data <= '2021-01-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes2/")
def tremembe_obitosNovosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes3/")
def tremembe_obitosNovosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes4/")
def tremembe_obitosNovosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes5/")
def tremembe_obitosNovosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes6/")
def tremembe_obitosNovosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes7/")
def tremembe_obitosNovosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y
    axis.grid()

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes8/")
def tremembe_obitosNovosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes9/")
def tremembe_obitosNovosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosNovosMes10/")
def tremembe_obitosNovosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/tremembe_obitosAcumuladosMes1/")
def tremembe_obitosAcumuladosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data <= '2021-01-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes2/")
def tremembe_obitosAcumuladosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes3/")
def tremembe_obitosAcumuladosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-03-01') &
                 (pushDataset1sem().data <= '2021-03-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes4/")
def tremembe_obitosAcumuladosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes5/")
def tremembe_obitosAcumuladosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes6/")
def tremembe_obitosAcumuladosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Tremembé') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes7/")
def tremembe_obitosAcumuladosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes8/")
def tremembe_obitosAcumuladosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes9/")
def tremembe_obitosAcumuladosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/tremembe_obitosAcumuladosMes10/")
def tremembe_obitosAcumuladosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Tremembé') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


# =======================================================
# ==============TABELAS DE PINDAMONHANGABA===============
# =======================================================
@app.route('/pindamonhangaba/')
def pinda():
    return render_template('/Pindamonhangaba/dados.html/')

@app.route('/pinda2021_pt1/')
def pinda2021_pt1():
    pinda_df = pd.DataFrame(pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'])
    return render_template('/Pindamonhangaba/1ºsemestre.html', tables=[pinda_df.to_html(classes='pinda_df', table_id="table")])

@app.route('/pinda2021_pt2/')
def pinda2021_pt2():
    pinda_df = pd.DataFrame(pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'])
    return render_template('/Pindamonhangaba/2ºsemestre.html', tables=[pinda_df.to_html(classes='pinda_df', table_id="table")])


# ===============================================
# ===============GRÁFICOS DE PINDA===============
# ===============================================
@app.route("/pinda_casosNovos1sem/")
def pinda_casosNovos1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos registrados por data - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovos2sem/")
def pinda_casosNovos2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos registrados por data - 2º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/pinda_casosAcumulados1sem/")
def pinda_casosAcumulados1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].casosAcumulado
    axis.plot(x, y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos acumulados (Total) - 1º Sem. 2021', fontsize=15)  # titulo
    axis.set_xlabel('data (semestre inteiro)')  # texto do eixo x
    axis.set_ylabel('casos acumulados')  # texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumulados2sem/")
def pinda_casosAcumulados2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].casosAcumulado
    axis.plot(x, y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Casos acumulados (Total) - 2º Sem. 2021', fontsize=15)  # titulo
    axis.set_xlabel('data (semestre inteiro)')  # texto do eixo x
    axis.set_ylabel('casos acumulados')  # texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/pinda_obitosNovos1sem/")
def pinda_obitosNovos1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].obitosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e obitosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos registrados por data - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovos2sem/")
def pinda_obitosNovos2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].obitosNovos
    axis.plot(x, y, marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos registrados por data - 2º Sem. 2021', fontsize=15)
    axis.set_xlabel('data (semestre inteiro)')
    axis.set_ylabel('óbitos novos')

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/pinda_obitosAcumulados1sem/")
def pinda_obitosAcumulados1sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset1sem()[pushDataset1sem().municipio == 'Pindamonhangaba'].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos acumulados (Total) - 1º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumulados2sem/")
def pinda_obitosAcumulados2sem():
    fig = Figure()
    rcParams['figure.figsize'] = 25, 5
    rcParams['figure.subplot.left'] = 0.03
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.0025
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].data
    y = pushDataset2sem()[pushDataset2sem().municipio == 'Pindamonhangaba'].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Óbitos acumulados (Total) - 2º Sem. 2021', fontsize=15) #titulo
    axis.set_xlabel('data (semestre inteiro)')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


# ===============================================
# ===========GRÁFICO MENSAL DE PINDA=============
# ===============================================
@app.route('/pinda_casosNovosMes/')
def pinda_casosNovosMes():
    return render_template('/Pindamonhangaba/casosNovosMes.html/')

@app.route('/pinda_casosAcumuladosMes/')
def pinda_casosAcumuladosMes():
    return render_template('/Pindamonhangaba/casosAcumuladosMes.html/')

@app.route('/pinda_obitosNovosMes/')
def pinda_obitosNovosMes():
    return render_template('/Pindamonhangaba/obitosNovosMes.html/')

@app.route('/pinda_obitosAcumuladosMes/')
def pinda_obitosAcumuladosMes():
    return render_template('/Pindamonhangaba/obitosAcumuladosMes.html/')


@app.route("/pinda_casosNovosMes1/")
def pinda_casosNovosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data <= '2021-01-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes2/")
def pinda_casosNovosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes3/")
def pinda_casosNovosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                 (pushDataset1sem().data <= '2021-03-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes4/")
def pinda_casosNovosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes5/")
def pinda_casosNovosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes6/")
def pinda_casosNovosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes7/")
def pinda_casosNovosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes8/")
def pinda_casosNovosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes9/")
def pinda_casosNovosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosNovosMes10/")
def pinda_casosNovosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].casosNovos
    axis.plot(x,y,marker='o') #mostrar grafico com data no eixo x e casosNovos no eixo y
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/pinda_casosAcumuladosMes1/")
def pinda_casosAcumuladosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') &
                          (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') &
                          (pushDataset1sem().data <= '2021-01-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes2")
def pinda_casosAcumuladosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes3/")
def pinda_casosAcumuladosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes4/")
def pinda_casosAcumuladosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes5/")
def pinda_casosAcumuladosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes6/")
def pinda_casosAcumuladosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes7/")
def pinda_casosAcumuladosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes8/")
def pinda_casosAcumuladosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes9/")
def pinda_casosAcumuladosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_casosAcumuladosMes10/")
def pinda_casosAcumuladosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].casosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('casos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/pinda_obitosNovosMes1/")
def pinda_obitosNovosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data <= '2021-01-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes2/")
def pinda_obitosNovosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes3/")
def pinda_obitosNovosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes4/")
def pinda_obitosNovosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes5/")
def pinda_obitosNovosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes6/")
def pinda_obitosNovosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes7/")
def pinda_obitosNovosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes8/")
def pinda_obitosNovosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes9/")
def pinda_obitosNovosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosNovosMes10/")
def pinda_obitosNovosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                          (pushDataset2sem().data <= '2021-10-31')].obitosNovos
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos novos')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


@app.route("/pinda_obitosAcumuladosMes1/")
def pinda_obitosAcumuladosMes1():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data <= '2021-01-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data <= '2021-01-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Janeiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes2/")
def pinda_obitosAcumuladosMes2():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-02-01') &
                          (pushDataset1sem().data <= '2021-02-28')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Fevereiro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes3/")
def pinda_obitosAcumuladosMes3():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-03-01') &
                          (pushDataset1sem().data <= '2021-03-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Março de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes4/")
def pinda_obitosAcumuladosMes4():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-04-01') &
                          (pushDataset1sem().data <= '2021-04-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Abril de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes5/")
def pinda_obitosAcumuladosMes5():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-05-01') &
                          (pushDataset1sem().data <= '2021-05-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Maio de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes6/")
def pinda_obitosAcumuladosMes6():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].data
    y = pushDataset1sem()[(pushDataset1sem().municipio == 'Pindamonhangaba') & (pushDataset1sem().data >= '2021-06-01') &
                          (pushDataset1sem().data <= '2021-06-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Junho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes7/")
def pinda_obitosAcumuladosMes7():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-07-01') &
                          (pushDataset2sem().data <= '2021-07-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Julho de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes8/")
def pinda_obitosAcumuladosMes8():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-08-01') &
                          (pushDataset2sem().data <= '2021-08-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Agosto de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes9/")
def pinda_obitosAcumuladosMes9():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.1
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-09-01') &
                          (pushDataset2sem().data <= '2021-09-30')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Setembro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')

@app.route("/pinda_obitosAcumuladosMes10/")
def pinda_obitosAcumuladosMes10():
    fig = Figure()
    rcParams['figure.figsize'] = 7, 5
    rcParams['figure.subplot.left'] = 0.2
    rcParams['figure.subplot.right'] = 1
    rcParams['axes.xmargin'] = 0.01
    axis = fig.add_subplot(1, 1, 1)

    x = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].data
    y = pushDataset2sem()[(pushDataset2sem().municipio == 'Pindamonhangaba') & (pushDataset2sem().data >= '2021-10-01') &
                 (pushDataset2sem().data <= '2021-10-31')].obitosAcumulado
    axis.plot(x,y,marker='o')
    axis.tick_params('x', labelrotation=90)
    axis.grid()

    fig.suptitle('Outubro de 2021', fontsize=15) #titulo
    axis.set_xlabel('datas')     #texto do eixo x
    axis.set_ylabel('óbitos acumulados')  #texto do eixo y

    img = io.BytesIO()
    FigureCanvas(fig).print_png(img)
    return Response(img.getvalue(), mimetype='image/png')


if __name__ == "__main__":
    app.run()